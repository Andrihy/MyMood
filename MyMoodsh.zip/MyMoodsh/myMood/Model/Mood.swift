//
//  Mood.swift
//  myMood
//
//  Created by Aleksandr Shapovalov on 24/10/22.
//

import Foundation
